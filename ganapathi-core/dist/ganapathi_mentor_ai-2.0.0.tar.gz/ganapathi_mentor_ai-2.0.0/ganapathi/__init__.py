"""
Ganapathi CLI v2.0 - Ultimate AI Terminal Mentor
Production-grade AI mentor CLI for B.Tech CSE AI students.
"""

__version__ = "2.0.0"
__author__ = "G R Harsha"
__app_name__ = "Ganapathi CLI"
